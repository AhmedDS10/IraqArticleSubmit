/**
 * Article Submission Form - Client-side functionality
 * Handles form validation and user interaction
 */

document.addEventListener('DOMContentLoaded', function() {
    // Get form elements
    const articleForm = document.getElementById('articleForm');
    const authorNameInput = document.getElementById('author_name');
    const articleTitleInput = document.getElementById('article_title');
    const articleContentInput = document.getElementById('article_content');
    const submitButton = document.getElementById('submitBtn');
    
    // Timeout for alert messages
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);  // Close alerts after 5 seconds
    
    // Character count limiter for the article content
    if (articleContentInput) {
        const contentCounter = document.getElementById('contentCounter');
        const MAX_CHARS = 5000;
        
        articleContentInput.addEventListener('input', function() {
            const currentLength = this.value.length;
            contentCounter.textContent = `${currentLength} / ${MAX_CHARS} حرف`;
            
            if (currentLength > MAX_CHARS) {
                contentCounter.classList.add('text-danger');
                contentCounter.classList.add('fw-bold');
            } else {
                contentCounter.classList.remove('text-danger');
                contentCounter.classList.remove('fw-bold');
            }
        });
        
        // Trigger the input event to initialize counter
        articleContentInput.dispatchEvent(new Event('input'));
    }
    
    // Prevent submission if form is invalid
    if (articleForm) {
        articleForm.addEventListener('submit', function(event) {
            if (!this.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            } else {
                // Form is valid, show loading state
                submitButton.disabled = true;
                submitButton.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>جارِ الإرسال...';
            }
            
            this.classList.add('was-validated');
        });
    }
    
    // Add input event listeners for real-time validation
    const requiredInputs = [authorNameInput, articleTitleInput, articleContentInput];
    requiredInputs.forEach(function(input) {
        if (input) {
            input.addEventListener('blur', function() {
                if (this.value.trim() === '') {
                    this.classList.add('is-invalid');
                } else {
                    this.classList.remove('is-invalid');
                    this.classList.add('is-valid');
                }
            });
        }
    });
});
